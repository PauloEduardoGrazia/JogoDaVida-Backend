export interface IWork {
    id: string;
    name: string;
    wageValue: number;
}