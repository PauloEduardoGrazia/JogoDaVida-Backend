export interface ICar{
    name: string;
    price: number;
}