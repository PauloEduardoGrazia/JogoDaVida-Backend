export interface IHouse{
    name: string;
    price: number;
}