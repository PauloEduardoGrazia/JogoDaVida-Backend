export interface IInsurance {
    id: string;
    name: string;
    price: number;
}