export interface UpdatePlayerDto {
    chooseUniversity?: boolean;
    workId?: string;
    insuranceId?: string;
    isMarried?: boolean;
    childrenCount?: number;
}